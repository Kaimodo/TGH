﻿---
external help file: TGH-help.xml
Module Name: TGH
online version: https://www.github.com/Kaimodo/TGH
schema: 2.0.0
---

# Show-Fish

## SYNOPSIS
Shows some Fish

## SYNTAX

```
Show-Fish
```

## DESCRIPTION
Fish 4 free

## EXAMPLES

### BEISPIEL 1
```
Show-Fish
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES
Author: Kai Krutscho

## RELATED LINKS

[https://www.github.com/Kaimodo/TGH](https://www.github.com/Kaimodo/TGH)

