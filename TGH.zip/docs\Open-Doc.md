﻿---
external help file: TGH-help.xml
Module Name: TGH
online version: https://www.github.com/Kaimodo/TGH
schema: 2.0.0
---

# Open-Doc

## SYNOPSIS
Sets the working directory to the user's documents folder

## SYNTAX

```
Open-Doc
```

## DESCRIPTION
This scripts changes the working directory to the user's documents folder.

## EXAMPLES

### BEISPIEL 1
```
./cd-docs
```

📂/home/markus/Documents

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES
Author: Kai Krutscho

## RELATED LINKS

[https://www.github.com/Kaimodo/TGH](https://www.github.com/Kaimodo/TGH)

